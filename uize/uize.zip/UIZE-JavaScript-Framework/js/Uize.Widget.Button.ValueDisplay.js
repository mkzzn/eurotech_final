/*
	UIZE JAVASCRIPT FRAMEWORK 2012-01-10

	http://www.uize.com/reference/Uize.Widget.Button.ValueDisplay.html
	Available under MIT License or GNU General Public License -- http://www.uize.com/license.html
*/
Uize.module({name:'Uize.Widget.Button.ValueDisplay',builder:function(d_a){var d_b=d_a.subclass();d_b.registerProperties({d_c:'defaultValueDetails',d_d:'value',d_e:{name:'valueDetails',conformer:function(d_e){return d_e||this.d_c}}});return d_b;}});