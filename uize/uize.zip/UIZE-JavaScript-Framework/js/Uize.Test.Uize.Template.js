/*
	UIZE JAVASCRIPT FRAMEWORK 2012-01-10

	http://www.uize.com/reference/Uize.Test.Uize.Template.html
	Available under MIT License or GNU General Public License -- http://www.uize.com/license.html
*/
Uize.module({name:'Uize.Test.Uize.Template',builder:function(){return Uize.Test.declare({title:'Test for Uize.Template Module',test:[Uize.Test.requiredModulesTest('Uize.Template'),Uize.Test.staticMethodsTest([['Uize.Template.encode',[]],['Uize.Template.decode',[]],['Uize.Template.defineStandardEncoding',[]],['Uize.Template.compile',[]]])]});}});