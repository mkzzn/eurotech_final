var animals = [
	{
		title:'Pets',
		items:[
			{
				title:'Dogs',
				items:[
					{
						title:'Small Breeds',
						items:[
							{title:'West Highland White'},
							{title:'Mexican Hairless'},
							{title:'Miniature Chihuahua'},
							{title:'Teacup Poodle'}
						]
					},
					{
						title:'Large Breeds',
						items:[
							{title:'Afghan'},
							{title:'Great Dane'},
							{title:'Irish Wolfhound'},
							{title:'St. Bernard'}
						]
					}
				]
			},
			{
				title:'Cats',
				items:[
					{title:'Persian'},
					{title:'Siamese'},
					{title:'Hairless'}
				]
			},
			{
				title:'Other',
				items:[
					{title:'Bunny'},
					{title:'Hamster'},
					{title:'Mouse'},
					{title:'Rat'}
				]
			}
		]
	},
	{
		title:'Wild Animals',
		items:[
			{
				title:'Dogs',
				items:[
					{title:'Coyote'},
					{title:'Dingo'}
				]
			},
			{
				title:'Cats',
				items:[
					{title:'Bobcat'},
					{title:'Cheetah'},
					{title:'Leopard'},
					{title:'Lion'},
					{title:'Lynx'},
					{title:'Mountain Lion'},
					{title:'Tiger'}
				]
			},
			{
				title:'Other',
				items:[
					{title:'Aardvark'},
					{title:'Elephant'},
					{title:'Hedgehog'},
					{title:'Opossum'},
					{title:'Water Buffalo'},
					{title:'Wildebeest'},
					{title:'Wild Boar'},
					{title:'Zebra'}
				]
			}
		]
	}
];

